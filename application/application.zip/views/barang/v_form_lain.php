<div class="form-group">
	<label for="nama_barang_lain" class="col-sm-2 control-label">Nama Barang</label>
	<div class="col-sm-4">
	  <input type="text" class="form-control" id="nama_barang_lain" name="nama_barang_lain" placeholder="Nama Barang" value="<?php if(isset($nama_barang_lain)){echo $nama_barang_lain;}?>" >
	</div>
</div>
<div class="form-group">
	<label for="sn_other" class="col-sm-2 control-label">Serial Number</label>
	<div class="col-sm-4">
	  <input type="text" class="form-control" id="sn_other" name="sn_other" placeholder="Serial Number" value="<?php if(isset($sn_other)){echo $sn_other;}?>" >
	</div>
</div>

