  <div class="form-group">
    <label for="sn_smartphone" class="col-sm-2 control-label">Serial Smartphone</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="sn_smartphone" name="sn_smartphone" placeholder="Serial Number Smartphone" value="<?php if(isset($sn_smartphone)){echo $sn_smartphone;}?>" >
    </div>
  </div>
  <div class="form-group">
    <label for="imei1" class="col-sm-2 control-label">Imei 1</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="imei1" name="imei1" placeholder="Imei 1" value="<?php if(isset($imei1)){echo $imei2;}?>" >
    </div>
  </div>
  <div class="form-group">
    <label for="imei2" class="col-sm-2 control-label">Imei 2</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="imei2" name="imei2" placeholder="Imei 2" value="<?php if(isset($imei2)){echo $imei2;}?>" >
    </div>
  </div>