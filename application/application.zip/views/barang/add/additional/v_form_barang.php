<div class="form-group">
	<label for="sn" class="col-sm-2 control-label">Serial Number</label>
	<div class="col-sm-4">
	  <input type="text" class="form-control" id="sn" name="sn" placeholder="Serial Number" value="<?php if(isset($sn)){echo $sn;}?>" required>
	</div>
</div>
