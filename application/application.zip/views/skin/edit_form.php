<script type="text/javascript">
	//select2
		$(function(){
	      // turn the element to select2 select style
	      $('.select2').select2();
	    });
</script>